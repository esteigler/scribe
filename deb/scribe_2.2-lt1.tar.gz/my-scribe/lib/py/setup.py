from distutils.core import setup

setup(name='scribe',
      version='2.0',
      packages=['scribe'],
      )

